import React, { useEffect, useMemo, useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  SafeAreaView, StatusBar, TextInput, Alert
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const GREEN = '#B6F36A';
const BG = '#10120F';
const CARD = '#1C201A';
const MUTED = '#92998C';
const STORAGE_KEY = '@aifit_user_data_v4';
const API_URL = 'https://ai-fit-backend.onrender.com';

const todayKey = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
};

const dateKey = d =>
  `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;

const formatDate = key => {
  if (!key) return '';
  const [y,m,d] = key.split('-').map(Number);
  return new Date(y,m-1,d).toLocaleDateString('en-US',{month:'short',day:'numeric'});
};

const defaultAnswers = {
  goal:'Build muscle',
  bodyType:'Slim',
  age:'',
  height:'',
  weight:'',
  experience:'Beginner',
  days:'3 days',
  equipment:'Gym'
};

const exercises = [
  {id:'1',name:'Bench press',muscle:'Chest',sets:3,reps:'8–12',equipment:'Gym',emoji:'🏋️',level:'Beginner',instructions:'Keep your feet planted, lower the bar with control and press upward.'},
  {id:'2',name:'Incline dumbbell press',muscle:'Chest',sets:3,reps:'8–12',equipment:'Gym',emoji:'💪',level:'Intermediate',instructions:'Use a slight incline and lower the dumbbells slowly.'},
  {id:'3',name:'Push-ups',muscle:'Chest',sets:3,reps:'8–15',equipment:'No equipment',emoji:'🤸',level:'Beginner',instructions:'Keep your body straight and lower your chest toward the floor.'},
  {id:'4',name:'Cable fly',muscle:'Chest',sets:3,reps:'12–15',equipment:'Gym',emoji:'🏋️',level:'Intermediate',instructions:'Use a controlled arc and squeeze your chest.'},
  {id:'5',name:'Lat pulldown',muscle:'Back',sets:3,reps:'10–12',equipment:'Gym',emoji:'💪',level:'Beginner',instructions:'Pull the bar toward your upper chest.'},
  {id:'6',name:'Seated cable row',muscle:'Back',sets:3,reps:'10–12',equipment:'Gym',emoji:'🏋️',level:'Beginner',instructions:'Pull toward your waist and squeeze your shoulder blades.'},
  {id:'7',name:'Pull-ups',muscle:'Back',sets:3,reps:'6–10',equipment:'Home equipment',emoji:'🔥',level:'Advanced',instructions:'Start from a controlled hang and pull yourself upward.'},
  {id:'8',name:'Dumbbell row',muscle:'Back',sets:3,reps:'10–12',equipment:'Gym',emoji:'💪',level:'Beginner',instructions:'Keep your back neutral and pull toward your hip.'},
  {id:'9',name:'Shoulder press',muscle:'Shoulders',sets:3,reps:'8–12',equipment:'Gym',emoji:'🏋️',level:'Beginner',instructions:'Brace your core and press overhead.'},
  {id:'10',name:'Lateral raises',muscle:'Shoulders',sets:3,reps:'12–15',equipment:'Gym',emoji:'💪',level:'Beginner',instructions:'Raise the weights out to your sides.'},
  {id:'11',name:'Bicep curls',muscle:'Arms',sets:3,reps:'10–12',equipment:'Gym',emoji:'💪',level:'Beginner',instructions:'Keep your elbows close and avoid swinging.'},
  {id:'12',name:'Hammer curls',muscle:'Arms',sets:3,reps:'10–12',equipment:'Gym',emoji:'🏋️',level:'Beginner',instructions:'Keep your palms facing each other.'},
  {id:'13',name:'Tricep pushdown',muscle:'Arms',sets:3,reps:'10–15',equipment:'Gym',emoji:'💪',level:'Beginner',instructions:'Keep your elbows tucked in.'},
  {id:'14',name:'Tricep dips',muscle:'Arms',sets:3,reps:'8–12',equipment:'Home equipment',emoji:'🔥',level:'Intermediate',instructions:'Lower yourself with control.'},
  {id:'15',name:'Squats',muscle:'Legs',sets:3,reps:'12–15',equipment:'No equipment',emoji:'🦵',level:'Beginner',instructions:'Keep your feet stable and your chest upright.'},
  {id:'16',name:'Goblet squat',muscle:'Legs',sets:3,reps:'10–12',equipment:'Gym',emoji:'🏋️',level:'Beginner',instructions:'Hold a dumbbell at chest height and squat.'},
  {id:'17',name:'Leg press',muscle:'Legs',sets:3,reps:'10–12',equipment:'Gym',emoji:'💪',level:'Beginner',instructions:'Lower the platform under control.'},
  {id:'18',name:'Romanian deadlift',muscle:'Legs',sets:3,reps:'8–12',equipment:'Gym',emoji:'🏋️',level:'Intermediate',instructions:'Push your hips back and keep your back neutral.'},
  {id:'19',name:'Lunges',muscle:'Legs',sets:3,reps:'10 each leg',equipment:'No equipment',emoji:'🦵',level:'Beginner',instructions:'Take a stable step and lower your back knee.'},
  {id:'20',name:'Plank',muscle:'Core',sets:3,reps:'30–45 sec',equipment:'No equipment',emoji:'🔥',level:'Beginner',instructions:'Keep your body straight and brace your core.'},
  {id:'21',name:'Crunches',muscle:'Core',sets:3,reps:'15–20',equipment:'No equipment',emoji:'🤸',level:'Beginner',instructions:'Lift your shoulders gently.'},
  {id:'22',name:'Leg raises',muscle:'Core',sets:3,reps:'10–15',equipment:'No equipment',emoji:'🔥',level:'Intermediate',instructions:'Control your lower back as you raise your legs.'},
  {id:'23',name:'Mountain climbers',muscle:'Cardio',sets:3,reps:'30 sec',equipment:'No equipment',emoji:'🏃',level:'Beginner',instructions:'Alternate your knees forward while holding a plank.'},
  {id:'24',name:'Jumping jacks',muscle:'Cardio',sets:3,reps:'30 sec',equipment:'No equipment',emoji:'🏃',level:'Beginner',instructions:'Jump your feet apart and raise your arms.'}
];

const achievements = [
  {id:'a1',name:'First step',description:'Complete your first workout',icon:'🌱',target:1},
  {id:'a2',name:'Getting started',description:'Complete 3 workouts',icon:'💪',target:3},
  {id:'a3',name:'One week strong',description:'Complete 7 workouts',icon:'🔥',target:7},
  {id:'a4',name:'Dedicated',description:'Complete 10 workouts',icon:'🏆',target:10},
  {id:'a5',name:'Committed',description:'Complete 20 workouts',icon:'🥇',target:20},
  {id:'a6',name:'Consistency',description:'Reach a 3-day streak',icon:'⚡',streak:3},
  {id:'a7',name:'Unstoppable',description:'Reach a 7-day streak',icon:'👑',streak:7}
];

const mealPresets = [
  {name:'Eggs and toast',calories:350,protein:22,carbs:30,fat:15},
  {name:'Chicken and rice',calories:550,protein:45,carbs:60,fat:12},
  {name:'Greek yogurt',calories:150,protein:17,carbs:10,fat:4},
  {name:'Oatmeal',calories:300,protein:12,carbs:48,fat:7},
  {name:'Protein shake',calories:180,protein:30,carbs:8,fat:3},
  {name:'Salmon and potatoes',calories:600,protein:38,carbs:55,fat:22}
];

export default function App() {
  const [tab,setTab] = useState('Home');
  const [answers,setAnswers] = useState(defaultAnswers);
  const [profileComplete,setProfileComplete] = useState(false);
  const [showPersonalization,setShowPersonalization] = useState(false);
  const [step,setStep] = useState(0);
  const [hydrated,setHydrated] = useState(false);

  const [completedDates,setCompletedDates] = useState([]);
  const [water,setWater] = useState(0);
  const [waterDate,setWaterDate] = useState(todayKey());
  const [weightEntries,setWeightEntries] = useState([]);
  const [chatMessages,setChatMessages] = useState([
    {id:'welcome',from:'coach',text:"Hey! I'm your AI FIT assistant. Ask me anything — fitness, school, technology, travel or everyday life. I'm here to help."}
  ]);
  const [chatInput,setChatInput] = useState('');
  const [isTyping,setIsTyping] = useState(false);
  const [conversations,setConversations] = useState([]);
  const [xp,setXp] = useState(0);

  const [search,setSearch] = useState('');
  const [muscleFilter,setMuscleFilter] = useState('All');
  const [selectedExercise,setSelectedExercise] = useState(null);
  const [workoutStarted,setWorkoutStarted] = useState(false);
  const [completedExercises,setCompletedExercises] = useState([]);
  const [workoutLogs,setWorkoutLogs] = useState([]);
  const [calendarMonth,setCalendarMonth] = useState(new Date());
  const [selectedDate,setSelectedDate] = useState(todayKey());

  const [foodEntries,setFoodEntries] = useState([]);
  const [foodSearch,setFoodSearch] = useState('');
  const [customFood,setCustomFood] = useState({name:'',calories:'',protein:'',carbs:'',fat:''});

  const [goalCalories,setGoalCalories] = useState(2400);
  const [goalProtein,setGoalProtein] = useState(150);
  const [goalWater,setGoalWater] = useState(8);

  const today = todayKey();

  useEffect(() => {
    const load = async () => {
      try {
        const raw = await AsyncStorage.getItem(STORAGE_KEY);
        if (raw) {
          const d = JSON.parse(raw);
          setAnswers({...defaultAnswers,...(d.answers || {})});
          setProfileComplete(!!d.profileComplete);
          setCompletedDates(d.completedDates || []);
          setWater(d.waterDate === todayKey() ? (d.water || 0) : 0);
          setWaterDate(todayKey());
          setWeightEntries(d.weightEntries || []);
          setChatMessages(d.chatMessages || [
            {id:'welcome',from:'coach',text:"Hey! I'm your AI FIT assistant. Ask me anything."}
          ]);
          setConversations(d.conversations || []);
          setXp(d.xp || 0);
          setWorkoutLogs(d.workoutLogs || []);
          setFoodEntries(d.foodEntries || []);
          setGoalCalories(d.goalCalories || 2400);
          setGoalProtein(d.goalProtein || 150);
          setGoalWater(d.goalWater || 8);
        }
      } catch(e) {
        console.log('Load error:',e);
      } finally {
        setHydrated(true);
      }
    };
    load();
  },[]);

  useEffect(() => {
    if (!hydrated) return;
    AsyncStorage.setItem(STORAGE_KEY,JSON.stringify({
      answers,profileComplete,completedDates,water,waterDate,
      weightEntries,chatMessages,conversations,xp,workoutLogs,
      foodEntries,goalCalories,goalProtein,goalWater
    })).catch(e => console.log('Save error:',e));
  },[
    hydrated,answers,profileComplete,completedDates,water,waterDate,
    weightEntries,chatMessages,conversations,xp,workoutLogs,
    foodEntries,goalCalories,goalProtein,goalWater
  ]);

  useEffect(() => {
    if (waterDate !== today) {
      setWater(0);
      setWaterDate(today);
    }
  },[today,waterDate]);

  const update = (key,value) => setAnswers(p => ({...p,[key]:value}));
  const workoutCount = completedDates.length;

  const streak = useMemo(() => {
    const dates = new Set(completedDates);
    const cursor = new Date();
    if (!dates.has(dateKey(cursor))) {
      cursor.setDate(cursor.getDate()-1);
      if (!dates.has(dateKey(cursor))) return 0;
    }
    let n = 0;
    while (dates.has(dateKey(cursor))) {
      n++;
      cursor.setDate(cursor.getDate()-1);
    }
    return n;
  },[completedDates]);

  const weeklyCount = useMemo(() => {
    let n = 0;
    for (let i=0;i<7;i++) {
      const d = new Date();
      d.setDate(d.getDate()-i);
      if (completedDates.includes(dateKey(d))) n++;
    }
    return n;
  },[completedDates]);

  const level = Math.floor(xp/500)+1;
  const levelProgress = xp%500;
  const unlocked = achievements.filter(a =>
    a.target ? workoutCount>=a.target : streak>=a.streak
  ).length;

  const todayFood = foodEntries.filter(f => f.date===today);
  const totals = todayFood.reduce((a,f) => ({
    calories:a.calories+Number(f.calories || 0),
    protein:a.protein+Number(f.protein || 0),
    carbs:a.carbs+Number(f.carbs || 0),
    fat:a.fat+Number(f.fat || 0)
  }),{calories:0,protein:0,carbs:0,fat:0});

  const progress = (value,total) => (
    <View style={styles.track}>
      <View style={[styles.fill,{width:`${Math.min(100,total ? value/total*100 : 0)}%`}]} />
    </View>
  );

  const heading = (title,right='') => (
    <View style={styles.sectionHeading}>
      <Text style={styles.sectionTitle}>{title}</Text>
      <Text style={styles.muted}>{right}</Text>
    </View>
  );

  const card = (children,extra={}) => (
    <View style={[styles.card,extra]}>{children}</View>
  );

  const button = (label,onPress,secondary=false) => (
    <TouchableOpacity
      style={secondary ? styles.secondaryButton : styles.greenButton}
      onPress={onPress}
    >
      <Text style={secondary ? styles.secondaryButtonText : styles.greenButtonText}>
        {label}
      </Text>
    </TouchableOpacity>
  );

  const startPersonalization = () => {
    setStep(0);
    setShowPersonalization(true);
  };

  const finishPersonalization = () => {
    const age = Number(answers.age);
    const height = Number(answers.height);
    const weight = Number(answers.weight);

    if (!age || age<13 || age>100) {
      Alert.alert('Check your age','Enter an age between 13 and 100.');
      setStep(2);
      return;
    }
    if (!height || height<100 || height>250) {
      Alert.alert('Check your height','Enter a height between 100 and 250 cm.');
      setStep(2);
      return;
    }
    if (!weight || weight<25 || weight>300) {
      Alert.alert('Check your weight','Enter a valid weight.');
      setStep(2);
      return;
    }

    setProfileComplete(true);
    setShowPersonalization(false);
    setTab('Home');
    setXp(p=>p+50);
    Alert.alert('Profile created! 🎉','You earned 50 XP.');
  };

  const steps = [
    {
      title:"What's your main goal?",
      subtitle:'Your plan will be adapted to your goal.',
      key:'goal',
      options:['Build muscle','Lose body fat','Body recomposition','Improve overall fitness']
    },
    {
      title:'Your body type',
      subtitle:'Optional information for your profile.',
      key:'bodyType',
      options:['Slim','Average','Athletic','Higher body fat']
    },
    {
      title:'About you',
      subtitle:'Enter your basic information.',
      key:null
    },
    {
      title:'Experience level',
      subtitle:'Choose your current training experience.',
      key:'experience',
      options:['Beginner','Intermediate','Advanced']
    },
    {
      title:'Weekly schedule',
      subtitle:'How many days can you train?',
      key:'days',
      options:['2 days','3 days','4 days','5 days','6 days']
    },
    {
      title:'Training equipment',
      subtitle:'Where do you usually train?',
      key:'equipment',
      options:['Gym','Home with equipment','Home without equipment']
    }
  ];

  const personalizationScreen = () => {
    const current = steps[step];
    return (
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Text style={styles.logo}>AI<Text style={styles.green}>FIT</Text></Text>
          <TouchableOpacity onPress={()=>setShowPersonalization(false)}>
            <Text style={styles.muted}>CLOSE ✕</Text>
          </TouchableOpacity>
        </View>
        <Text style={styles.eyebrow}>PERSONALIZATION</Text>
        <View style={styles.progressRow}>
          {steps.map((s,i)=><View key={i} style={[styles.stepBar,{backgroundColor:i<=step?GREEN:'#343A30'}]}/>)}
        </View>
        <Text style={styles.muted}>STEP {step+1} OF 6</Text>
        <Text style={styles.pageTitle}>{current.title}</Text>
        <Text style={styles.muted}>{current.subtitle}</Text>

        <View style={{marginTop:22}}>
          {step===2 ? (
            [['age','Age','years'],['height','Height','cm'],['weight','Weight','kg']].map(([key,label,unit])=>(
              <View key={key} style={{marginBottom:15}}>
                <Text style={styles.cardTitle}>{label}</Text>
                <TextInput
                  value={answers[key]}
                  onChangeText={v=>update(key,v.replace(/[^0-9.]/g,''))}
                  keyboardType="numeric"
                  placeholder={`Enter ${unit}`}
                  placeholderTextColor={MUTED}
                  style={styles.input}
                />
              </View>
            ))
          ) : current.options.map(option=>(
            <TouchableOpacity
              key={option}
              onPress={()=>update(current.key,option)}
              style={[styles.optionCard,answers[current.key]===option && styles.optionSelected]}
            >
              <Text style={styles.optionText}>{option}</Text>
              <Text style={styles.green}>{answers[current.key]===option?'✓':'○'}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {button(step===5?'CREATE MY PROFILE →':'CONTINUE →',()=>step<5?setStep(step+1):finishPersonalization())}
        {step>0 && button('← GO BACK',()=>setStep(step-1),true)}
      </ScrollView>
    );
  };

  const completeWorkout = () => {
    if (!completedExercises.length) {
      Alert.alert('No exercises completed','Mark at least one exercise before finishing.');
      return;
    }
    if (completedDates.includes(today)) {
      Alert.alert('Already completed','You have already recorded a workout today.');
      return;
    }
    setCompletedDates(p=>[...new Set([...p,today])].sort());
    setWorkoutLogs(p=>[...p,{
      date:today,
      exercises:completedExercises.length,
      names:completedExercises.map(id=>exercises.find(e=>e.id===id)?.name).filter(Boolean)
    }]);
    setXp(p=>p+100+completedExercises.length*10);
    setWorkoutStarted(false);
    setCompletedExercises([]);
    Alert.alert('Workout completed! 🏆','You earned XP. Keep up the great work!');
  };

  const filteredExercises = exercises.filter(e =>
    e.name.toLowerCase().includes(search.toLowerCase()) &&
    (muscleFilter==='All' || e.muscle===muscleFilter)
  );

  const homeScreen = () => (
    <ScrollView showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <View>
          <Text style={styles.eyebrow}>YOUR PERSONAL FITNESS PLATFORM</Text>
          <Text style={styles.logo}>AI<Text style={styles.green}>FIT</Text></Text>
        </View>
        <TouchableOpacity style={styles.avatar} onPress={()=>setTab('Profile')}>
          <Text style={styles.avatarText}>A</Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.pageTitle}>Let's get stronger.</Text>
      <Text style={styles.muted}>{profileComplete?`Your goal: ${answers.goal}`:'Your journey starts here. 💪'}</Text>

      {!profileComplete && card(
        <>
          <Text style={styles.cardTitle}>Create your fitness profile</Text>
          <Text style={styles.muted}>Get a personalized experience.</Text>
          {button('PERSONALIZE MY PLAN →',startPersonalization)}
        </>,
        {backgroundColor:'#273322',marginTop:18}
      )}

      <View style={styles.hero}>
        <Text style={styles.eyebrow}>YOUR FITNESS JOURNEY</Text>
        <Text style={styles.heroTitle}>Become your strongest self.</Text>
        <Text style={styles.heroDescription}>Small steps. Consistent progress.</Text>
        {button('START TRAINING →',()=>setTab('Workout'))}
        <Text style={styles.heroDecoration}>AIFIT</Text>
      </View>

      <View style={styles.statsRow}>
        <Stat icon="🔥" value={streak} label="Day streak"/>
        <Stat icon="🏋️" value={workoutCount} label="Workouts"/>
        <Stat icon="⭐" value={xp} label="Total XP"/>
      </View>

      {heading('Your level',`LEVEL ${level}`)}
      {card(
        <>
          <View style={styles.row}>
            <Text style={styles.cardTitle}>Level {level}</Text>
            <Text style={styles.green}>{levelProgress}/500 XP</Text>
          </View>
          {progress(levelProgress,500)}
          <Text style={styles.muted}>{500-levelProgress} XP until your next level.</Text>
        </>
      )}

      {heading("This week's activity",`${weeklyCount}/7 DAYS`)}
      {card(
        <View style={styles.weekRow}>
          {['M','T','W','T','F','S','S'].map((day,i)=>{
            const d=new Date();
            d.setDate(d.getDate()-((d.getDay()+6)%7)+i);
            const done=completedDates.includes(dateKey(d));
            return (
              <View key={i} style={styles.weekDay}>
                <Text style={styles.muted}>{day}</Text>
                <View style={[styles.dayDot,done&&styles.dayDotDone]}>
                  <Text style={[styles.dayDotText,done&&{color:BG}]}>{done?'✓':d.getDate()}</Text>
                </View>
              </View>
            );
          })}
        </View>
      )}

      {heading('Daily hydration',`${water}/${goalWater} GLASSES`)}
      {card(
        <>
          <View style={styles.row}>
            <Text style={styles.cardTitle}>💧 Water intake</Text>
            <Text style={styles.green}>{Math.round(water/goalWater*100)}%</Text>
          </View>
          {progress(water,goalWater)}
          <View style={styles.row}>
            {button('−',()=>setWater(Math.max(0,water-1)),true)}
            {button('+ ADD GLASS',()=>setWater(Math.min(goalWater,water+1)))}
          </View>
        </>
      )}

      {heading("Today's nutrition",`${Math.round(totals.calories)} KCAL`)}
      {card(
        <>
          <Text style={styles.cardTitle}>Daily calorie progress</Text>
          {progress(totals.calories,goalCalories)}
          <Text style={styles.muted}>{Math.max(0,goalCalories-totals.calories)} kcal remaining</Text>
          {button('OPEN NUTRITION →',()=>setTab('Nutrition'))}
        </>
      )}

      {heading('Your AI assistant','ALWAYS AVAILABLE')}
      <TouchableOpacity style={styles.coachCard} onPress={()=>setTab('Coach')}>
        <Text style={styles.coachIcon}>✦</Text>
        <View style={{flex:1}}>
          <Text style={styles.cardTitle}>Talk to AI FIT</Text>
          <Text style={styles.muted}>Ask anything. Get intelligent answers.</Text>
        </View>
        <Text style={styles.green}>→</Text>
      </TouchableOpacity>
      <View style={{height:25}}/>
    </ScrollView>
  );

  const workoutScreen = () => (
    <ScrollView showsVerticalScrollIndicator={false}>
      <Text style={styles.eyebrow}>YOUR TRAINING</Text>
      <Text style={styles.pageTitle}>Workouts</Text>
      <Text style={styles.muted}>Build strength. Track progress. Improve every day.</Text>

      {card(
        <>
          <Text style={styles.eyebrow}>YOUR PERSONAL PLAN</Text>
          <Text style={styles.heroTitle}>{profileComplete?answers.goal:'Build your routine'}</Text>
          <Text style={styles.muted}>{profileComplete?`${answers.experience} · ${answers.days} · ${answers.equipment}`:'Complete your profile to personalize training.'}</Text>
          {button('ASK AI FOR A WORKOUT →',()=>{
            setTab('Coach');
            setChatInput('Create a personalized weekly workout plan for me.');
          })}
        </>
      )}

      {card(
        <>
          <Text style={styles.cardTitle}>Today's workout</Text>
          <Text style={styles.muted}>{completedDates.includes(today)?'Workout completed today. Great job!':'Select exercises and record your session.'}</Text>
          {!workoutStarted ? button('START WORKOUT SESSION →',()=>{setWorkoutStarted(true);setCompletedExercises([]);}) : (
            <>
              <Text style={styles.green}>SESSION IN PROGRESS</Text>
              <Text style={styles.muted}>{completedExercises.length} exercises selected</Text>
              {exercises.slice(0,8).map(e=>(
                <TouchableOpacity key={e.id} style={styles.exercise} onPress={()=>setCompletedExercises(p=>p.includes(e.id)?p.filter(x=>x!==e.id):[...p,e.id])}>
                  <Text style={styles.exerciseCheck}>{completedExercises.includes(e.id)?'✓':'○'}</Text>
                  <View style={{flex:1}}>
                    <Text style={styles.cardTitle}>{e.name}</Text>
                    <Text style={styles.muted}>{e.sets} sets · {e.reps}</Text>
                  </View>
                </TouchableOpacity>
              ))}
              {button('COMPLETE WORKOUT + XP',completeWorkout)}
              {button('CANCEL SESSION',()=>{setWorkoutStarted(false);setCompletedExercises([]);},true)}
            </>
          )}
        </>
      )}

      {heading('Exercise library',`${exercises.length} EXERCISES`)}
      <TextInput value={search} onChangeText={setSearch} placeholder="Search exercises..." placeholderTextColor={MUTED} style={styles.input}/>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginVertical:12}}>
        {['All','Chest','Back','Shoulders','Arms','Legs','Core','Cardio'].map(m=>(
          <TouchableOpacity key={m} onPress={()=>setMuscleFilter(m)} style={[styles.chip,muscleFilter===m&&styles.chipActive]}>
            <Text style={[styles.chipText,muscleFilter===m&&{color:BG}]}>{m}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {filteredExercises.map(e=>(
        <TouchableOpacity key={e.id} style={styles.exercise} onPress={()=>setSelectedExercise(e)}>
          <Text style={styles.exerciseEmoji}>{e.emoji}</Text>
          <View style={{flex:1}}>
            <Text style={styles.cardTitle}>{e.name}</Text>
            <Text style={styles.muted}>{e.muscle} · {e.sets} sets · {e.reps}</Text>
          </View>
          <Text style={styles.green}>VIEW →</Text>
        </TouchableOpacity>
      ))}

      {heading('Workout history',`${workoutLogs.length} SESSIONS`)}
      {workoutLogs.slice(-10).reverse().map((log,i)=>(
        <View key={`${log.date}-${i}`} style={styles.exercise}>
          <Text style={styles.exerciseEmoji}>🏆</Text>
          <View style={{flex:1}}>
            <Text style={styles.cardTitle}>{formatDate(log.date)}</Text>
            <Text style={styles.muted}>{log.exercises} exercises completed</Text>
          </View>
        </View>
      ))}
      <View style={{height:30}}/>
    </ScrollView>
  );

  const addMeal = meal => {
    setFoodEntries(p=>[...p,{...meal,id:String(Date.now()),date:today}]);
    setXp(p=>p+5);
    Alert.alert('Meal added','Your food diary has been updated. +5 XP');
  };

  const addCustomMeal = () => {
    if (!customFood.name.trim() || !customFood.calories || Number(customFood.calories)<0) {
      Alert.alert('Missing information','Enter a food name and calorie amount.');
      return;
    }
    addMeal({
      name:customFood.name.trim(),
      calories:Number(customFood.calories),
      protein:Number(customFood.protein)||0,
      carbs:Number(customFood.carbs)||0,
      fat:Number(customFood.fat)||0
    });
    setCustomFood({name:'',calories:'',protein:'',carbs:'',fat:''});
  };

  const nutritionScreen = () => (
    <ScrollView showsVerticalScrollIndicator={false}>
      <Text style={styles.eyebrow}>FUEL YOUR BODY</Text>
      <Text style={styles.pageTitle}>Nutrition</Text>
      <Text style={styles.muted}>Track your food and understand your daily intake.</Text>

      {card(
        <>
          <Text style={styles.eyebrow}>DAILY CALORIES</Text>
          <Text style={styles.bigNumber}>{Math.round(totals.calories)} <Text style={styles.muted}>/ {goalCalories} kcal</Text></Text>
          {progress(totals.calories,goalCalories)}
          <Text style={styles.muted}>{Math.max(0,goalCalories-totals.calories)} kcal remaining</Text>
        </>
      )}

      {heading('Macronutrients','TODAY')}
      <View style={styles.macroRow}>
        <Macro label="Protein" value={totals.protein} goal={goalProtein} unit="g"/>
        <Macro label="Carbs" value={totals.carbs} goal={250} unit="g"/>
        <Macro label="Fat" value={totals.fat} goal={70} unit="g"/>
      </View>

      {heading('Daily targets','CUSTOMIZE')}
      {card(
        <>
          {[
            ['Calorie goal',goalCalories,setGoalCalories],
            ['Protein goal (g)',goalProtein,setGoalProtein],
            ['Water goal (glasses)',goalWater,setGoalWater]
          ].map(([label,value,setter])=>(
            <View key={label} style={styles.profileRow}>
              <Text style={styles.muted}>{label}</Text>
              <View style={styles.row}>
                <TouchableOpacity onPress={()=>setter(Math.max(1,value-50))}><Text style={styles.green}>−</Text></TouchableOpacity>
                <Text style={styles.profileValue}>{value}</Text>
                <TouchableOpacity onPress={()=>setter(value+50)}><Text style={styles.green}>+</Text></TouchableOpacity>
              </View>
            </View>
          ))}
        </>
      )}

      {heading('Add a meal','QUICK ADD')}
      {mealPresets.filter(m=>m.name.toLowerCase().includes(foodSearch.toLowerCase())).map(m=>(
        <TouchableOpacity key={m.name} style={styles.exercise} onPress={()=>addMeal(m)}>
          <Text style={styles.exerciseEmoji}>🥗</Text>
          <View style={{flex:1}}>
            <Text style={styles.cardTitle}>{m.name}</Text>
            <Text style={styles.muted}>{m.calories} kcal · P {m.protein}g · C {m.carbs}g · F {m.fat}g</Text>
          </View>
          <Text style={styles.green}>+ ADD</Text>
        </TouchableOpacity>
      ))}

      <TextInput value={foodSearch} onChangeText={setFoodSearch} placeholder="Search quick meals..." placeholderTextColor={MUTED} style={styles.input}/>

      {heading('Custom food','MANUAL ENTRY')}
      {card(
        <>
          {[
            ['name','Food name'],
            ['calories','Calories'],
            ['protein','Protein (g)'],
            ['carbs','Carbs (g)'],
            ['fat','Fat (g)']
          ].map(([key,label])=>(
            <TextInput
              key={key}
              value={customFood[key]}
              onChangeText={v=>setCustomFood(p=>({...p,[key]:v}))}
              placeholder={label}
              placeholderTextColor={MUTED}
              keyboardType={key==='name'?'default':'numeric'}
              style={styles.input}
            />
          ))}
          {button('ADD CUSTOM FOOD →',addCustomMeal)}
        </>
      )}

      {heading("Today's food diary",`${todayFood.length} ITEMS`)}
      {todayFood.length===0 && <Text style={styles.muted}>No meals added yet.</Text>}
      {todayFood.map(f=>(
        <View key={f.id} style={styles.exercise}>
          <View style={{flex:1}}>
            <Text style={styles.cardTitle}>{f.name}</Text>
            <Text style={styles.muted}>{f.calories} kcal · P {f.protein}g · C {f.carbs}g · F {f.fat}g</Text>
          </View>
          <TouchableOpacity onPress={()=>setFoodEntries(p=>p.filter(x=>x.id!==f.id))}>
            <Text style={styles.danger}>REMOVE</Text>
          </TouchableOpacity>
        </View>
      ))}

      {heading('Hydration','DAILY TRACKER')}
      {card(
        <>
          <Text style={styles.bigNumber}>💧 {water}/{goalWater}</Text>
          {progress(water,goalWater)}
          <View style={styles.row}>
            {button('−',()=>setWater(Math.max(0,water-1)),true)}
            {button('+ ADD WATER',()=>setWater(Math.min(goalWater,water+1)))}
          </View>
        </>
      )}
      <View style={{height:30}}/>
    </ScrollView>
  );

  const startNewChat = () => {
    if (chatMessages.some(m=>m.from==='user')) {
      setConversations(p=>[{
        id:String(Date.now()),
        title:chatMessages.find(m=>m.from==='user')?.text.slice(0,35)||'Previous chat',
        messages:chatMessages
      },...p]);
    }
    setChatMessages([{
      id:'welcome-'+Date.now(),
      from:'coach',
      text:"New conversation started! What would you like to talk about?"
    }]);
  };

  const sendCoachMessage = async () => {
    const message = chatInput.trim();
    if (!message || isTyping) return;

    const updated = [...chatMessages,{id:String(Date.now()),from:'user',text:message}];
    setChatMessages(updated);
    setChatInput('');
    setIsTyping(true);

    try {
      const history = updated
        .filter(m=>m.from==='user'||m.from==='coach')
        .slice(-20)
        .map(m=>({
          role:m.from==='user'?'user':'assistant',
          content:m.text
        }));

      const response = await fetch(`${API_URL}/chat`,{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({
          messages:history,
          profile:profileComplete?answers:null
        })
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.error||'AI request failed.');
      if (!data.reply) throw new Error('Empty AI response.');

      setChatMessages(p=>[...p,{
        id:String(Date.now()+1),
        from:'coach',
        text:data.reply
      }]);
    } catch(error) {
      console.log('AI error:',error);
      setChatMessages(p=>[...p,{
        id:String(Date.now()+2),
        from:'coach',
        text:'I could not connect to the AI right now. Please try again in a moment.'
      }]);
    } finally {
      setIsTyping(false);
    }
  };

  const coachScreen = () => (
    <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
      <View style={styles.row}>
        <View>
          <Text style={styles.eyebrow}>YOUR INTELLIGENT ASSISTANT</Text>
          <Text style={styles.pageTitle}>AI Coach ✦</Text>
        </View>
        <TouchableOpacity style={styles.secondaryButton} onPress={startNewChat}>
          <Text style={styles.secondaryButtonText}>+ NEW CHAT</Text>
        </TouchableOpacity>
      </View>

      {card(
        <>
          <Text style={styles.coachIcon}>✦</Text>
          <Text style={styles.cardTitle}>Your AI assistant</Text>
          <Text style={styles.muted}>Ask anything. From fitness and nutrition to science, technology, school, travel and everyday life.</Text>
          <Text style={styles.green}>● AI ASSISTANT</Text>
          {profileComplete && <Text style={styles.muted}>Your fitness profile is available as context.</Text>}
        </>
      )}

      {conversations.length>0 && (
        <>
          {heading('Previous conversations','HISTORY')}
          {conversations.slice(0,5).map(c=>(
            <TouchableOpacity key={c.id} style={styles.exercise} onPress={()=>setChatMessages(c.messages)}>
              <Text style={styles.cardTitle}>{c.title}</Text>
              <Text style={styles.green}>OPEN →</Text>
            </TouchableOpacity>
          ))}
        </>
      )}

      {heading('Conversation','LIVE CHAT')}
      {card(
        <>
          {chatMessages.map(m=>(
            <View key={m.id} style={[styles.chatBubble,m.from==='user'?styles.userBubble:styles.coachBubble]}>
              <Text style={styles.chatText}>{m.text}</Text>
            </View>
          ))}
          {isTyping && (
            <View style={[styles.chatBubble,styles.coachBubble]}>
              <Text style={styles.green}>AI IS THINKING...</Text>
            </View>
          )}
          <TextInput
            value={chatInput}
            onChangeText={setChatInput}
            placeholder="Ask me anything..."
            placeholderTextColor={MUTED}
            style={styles.input}
            multiline
            editable={!isTyping}
          />
          {button(isTyping?'AI IS THINKING...':'SEND MESSAGE →',sendCoachMessage)}
          <Text style={styles.muted}>AI responses may occasionally contain errors. Verify important information.</Text>
        </>
      )}
      <View style={{height:30}}/>
    </ScrollView>
  );

  const addWeight = () => {
    const value=Number(answers.weight);
    if (!value || value<25 || value>300) {
      Alert.alert('Invalid weight','Update your weight in your profile first.');
      return;
    }
    setWeightEntries(p=>[...p,{date:today,weight:value}]);
    setXp(p=>p+10);
    Alert.alert('Weight saved','Your progress has been updated. +10 XP');
  };

  const progressScreen = () => {
    const maxWeight=Math.max(1,...weightEntries.map(e=>e.weight));
    return (
      <ScrollView showsVerticalScrollIndicator={false}>
        <Text style={styles.eyebrow}>YOUR JOURNEY</Text>
        <Text style={styles.pageTitle}>Progress</Text>
        <Text style={styles.muted}>See how far you've come.</Text>

        <View style={styles.statsRow}>
          <Stat icon="🏋️" value={workoutCount} label="Workouts"/>
          <Stat icon="🔥" value={streak} label="Streak"/>
          <Stat icon="⭐" value={level} label="Level"/>
        </View>

        {heading('Workout activity','LAST 7 DAYS')}
        {card(
          <View style={styles.chart}>
            {Array.from({length:7},(_,i)=>{
              const d=new Date();
              d.setDate(d.getDate()-(6-i));
              const done=completedDates.includes(dateKey(d));
              return (
                <View key={i} style={styles.chartColumn}>
                  <View style={[styles.chartBar,{height:done?105:12,backgroundColor:done?GREEN:'#343A30'}]}/>
                  <Text style={styles.muted}>{d.toLocaleDateString('en-US',{weekday:'short'}).slice(0,1)}</Text>
                </View>
              );
            })}
          </View>
        )}

        {heading('Weight history','YOUR RECORDS')}
        {card(
          <>
            <Text style={styles.bigNumber}>{answers.weight||'--'} <Text style={styles.muted}>kg current profile weight</Text></Text>
            {button('SAVE CURRENT WEIGHT',addWeight)}
            {weightEntries.slice(-10).reverse().map((e,i)=>(
              <View key={`${e.date}-${i}`} style={styles.profileRow}>
                <Text style={styles.muted}>{formatDate(e.date)}</Text>
                <Text style={styles.profileValue}>{e.weight} kg</Text>
              </View>
            ))}
            {weightEntries.length===0 && <Text style={styles.muted}>Your weight history will appear here.</Text>}
          </>
        )}

        {heading('Training achievements',`${unlocked}/${achievements.length} UNLOCKED`)}
        {achievements.map(a=>{
          const done=a.target?workoutCount>=a.target:streak>=a.streak;
          return (
            <View key={a.id} style={[styles.achievement,!done&&{opacity:0.45}]}>
              <Text style={styles.achievementIcon}>{done?a.icon:'🔒'}</Text>
              <View style={{flex:1}}>
                <Text style={styles.cardTitle}>{a.name}</Text>
                <Text style={styles.muted}>{a.description}</Text>
              </View>
              <Text style={styles.green}>{done?'UNLOCKED':'LOCKED'}</Text>
            </View>
          );
        })}
        <View style={{height:30}}/>
      </ScrollView>
    );
  };

  const profileScreen = () => (
    <ScrollView showsVerticalScrollIndicator={false}>
      <Text style={styles.eyebrow}>YOUR ACCOUNT</Text>
      <Text style={styles.pageTitle}>Profile</Text>

      {card(
        <>
          <View style={styles.avatar}><Text style={styles.avatarText}>A</Text></View>
          <Text style={[styles.cardTitle,{marginTop:14}]}>Your fitness profile</Text>
          <Text style={styles.muted}>{profileComplete?'Your personal information and goals.':'Complete your profile to personalize your experience.'}</Text>
          {button(profileComplete?'EDIT PROFILE':'SET UP MY PROFILE',startPersonalization)}
        </>
      )}

      {profileComplete && card(
        <>
          {[
            ['Goal',answers.goal],
            ['Body type',answers.bodyType],
            ['Age',answers.age+' years'],
            ['Height',answers.height+' cm'],
            ['Weight',answers.weight+' kg'],
            ['Experience',answers.experience],
            ['Training days',answers.days],
            ['Equipment',answers.equipment]
          ].map(([k,v])=>(
            <View key={k} style={styles.profileRow}>
              <Text style={styles.muted}>{k}</Text>
              <Text style={styles.profileValue}>{v}</Text>
            </View>
          ))}
        </>
      )}

      {heading('Your account level',`LEVEL ${level}`)}
      {card(
        <>
          <Text style={styles.bigNumber}>⭐ {xp} XP</Text>
          {progress(levelProgress,500)}
          <Text style={styles.muted}>{500-levelProgress} XP until level {level+1}</Text>
        </>
      )}

      {heading('Settings','APP')}
      {card(
        <>
          <Text style={styles.cardTitle}>AI FIT</Text>
          <Text style={styles.muted}>Version 2.0 · Your personal fitness platform.</Text>
          {button('VIEW MY PROGRESS →',()=>setTab('Progress'),true)}
          {button('OPEN AI COACH →',()=>setTab('Coach'))}
        </>
      )}

      {button('RESET APP DATA',()=>{
        Alert.alert('Reset all data?','This removes your profile, workouts, food diary and chat history.',[
          {text:'Cancel',style:'cancel'},
          {text:'Reset',style:'destructive',onPress:async()=>{
            await AsyncStorage.removeItem(STORAGE_KEY);
            setAnswers(defaultAnswers);
            setProfileComplete(false);
            setCompletedDates([]);
            setWater(0);
            setWeightEntries([]);
            setChatMessages([{id:'welcome',from:'coach',text:'Welcome to AI FIT!'}]);
            setConversations([]);
            setXp(0);
            setWorkoutLogs([]);
            setFoodEntries([]);
            setWorkoutStarted(false);
            setCompletedExercises([]);
            setShowPersonalization(false);
            setTab('Home');
          }}
        ]);
      },true)}
      <View style={{height:30}}/>
    </ScrollView>
  );

  const screens = {
    Home:homeScreen,
    Workout:workoutScreen,
    Nutrition:nutritionScreen,
    Coach:coachScreen,
    Progress:progressScreen,
    Profile:profileScreen
  };

  const tabs = [
    {id:'Home',icon:'⌂',label:'Home'},
    {id:'Workout',icon:'🏋️',label:'Workout'},
    {id:'Nutrition',icon:'🥗',label:'Nutrition'},
    {id:'Coach',icon:'✦',label:'AI Coach'},
    {id:'Profile',icon:'◉',label:'Profile'}
  ];

  const calendarDays = useMemo(()=>{
    const y=calendarMonth.getFullYear();
    const m=calendarMonth.getMonth();
    const first=new Date(y,m,1);
    const offset=(first.getDay()+6)%7;
    const count=new Date(y,m+1,0).getDate();
    const cells=[];
    for(let i=0;i<offset;i++)cells.push(null);
    for(let d=1;d<=count;d++)cells.push(new Date(y,m,d));
    while(cells.length%7!==0)cells.push(null);
    return cells;
  },[calendarMonth]);

  if (!hydrated) {
    return (
      <SafeAreaView style={styles.container}>
        <StatusBar barStyle="light-content" backgroundColor={BG}/>
        <View style={styles.loading}>
          <Text style={styles.logo}>AI<Text style={styles.green}>FIT</Text></Text>
          <Text style={styles.muted}>Loading your fitness platform...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={BG}/>
      <View style={styles.content}>
        {showPersonalization ? personalizationScreen() :
          selectedExercise ? (
            <ScrollView showsVerticalScrollIndicator={false}>
              <TouchableOpacity onPress={()=>setSelectedExercise(null)}>
                <Text style={styles.green}>← BACK TO EXERCISES</Text>
              </TouchableOpacity>
              <Text style={styles.pageTitle}>{selectedExercise.name}</Text>
              <Text style={styles.muted}>{selectedExercise.muscle} · {selectedExercise.level}</Text>
              {card(
                <>
                  <Text style={styles.coachIcon}>{selectedExercise.emoji}</Text>
                  <Text style={styles.cardTitle}>Exercise instructions</Text>
                  <Text style={styles.muted}>{selectedExercise.instructions}</Text>
                  <View style={styles.profileRow}><Text style={styles.muted}>Sets</Text><Text style={styles.profileValue}>{selectedExercise.sets}</Text></View>
                  <View style={styles.profileRow}><Text style={styles.muted}>Reps</Text><Text style={styles.profileValue}>{selectedExercise.reps}</Text></View>
                  <View style={styles.profileRow}><Text style={styles.muted}>Equipment</Text><Text style={styles.profileValue}>{selectedExercise.equipment}</Text></View>
                </>
              )}
            </ScrollView>
          ) : screens[tab]()}
      </View>

      {!showPersonalization && !selectedExercise && (
        <View style={styles.tabBar}>
          {tabs.map(t=>(
            <TouchableOpacity key={t.id} style={styles.tab} onPress={()=>setTab(t.id)}>
              <Text style={[styles.tabIcon,tab===t.id&&{color:GREEN}]}>{t.icon}</Text>
              <Text style={[styles.tabLabel,tab===t.id&&{color:GREEN}]}>{t.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}
    </SafeAreaView>
  );
}

function Stat({icon,value,label}) {
  return (
    <View style={styles.statCard}>
      <Text style={styles.statIcon}>{icon}</Text>
      <Text style={styles.statNumber}>{value}</Text>
      <Text style={styles.muted}>{label}</Text>
    </View>
  );
}

function Macro({label,value,goal,unit}) {
  return (
    <View style={styles.macroCard}>
      <Text style={styles.muted}>{label}</Text>
      <Text style={styles.statNumber}>{Math.round(value)}{unit}</Text>
      <Text style={styles.muted}>/ {goal}{unit}</Text>
      <View style={styles.track}>
        <View style={[styles.fill,{width:`${Math.min(100,value/goal*100)}%`}]}/>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container:{flex:1,backgroundColor:BG},
  content:{flex:1,paddingHorizontal:18,paddingTop:14},
  loading:{flex:1,alignItems:'center',justifyContent:'center',gap:12},
  header:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:22},
  logo:{fontSize:28,fontWeight:'900',color:'white',letterSpacing:2},
  green:{color:GREEN,fontWeight:'900'},
  eyebrow:{fontSize:9,color:GREEN,letterSpacing:2,fontWeight:'900',marginBottom:8},
  pageTitle:{fontSize:30,fontWeight:'900',color:'white',marginTop:8,marginBottom:7},
  heroTitle:{fontSize:25,fontWeight:'900',color:'white',marginVertical:10},
  heroDescription:{fontSize:13,color:'#CBD2C4',lineHeight:20,marginBottom:10},
  hero:{backgroundColor:'#252F20',borderRadius:20,padding:21,marginVertical:20,overflow:'hidden'},
  heroDecoration:{position:'absolute',right:-5,bottom:-20,fontSize:60,fontWeight:'900',color:'#FFFFFF08'},
  muted:{fontSize:12,color:MUTED,lineHeight:19},
  card:{backgroundColor:CARD,borderRadius:17,padding:17,marginBottom:14},
  sectionHeading:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginTop:17,marginBottom:12},
  sectionTitle:{fontSize:16,color:'white',fontWeight:'900'},
  statsRow:{flexDirection:'row',gap:9,marginVertical:15},
  statCard:{flex:1,backgroundColor:CARD,borderRadius:14,padding:12},
  statIcon:{fontSize:20,marginBottom:8},
  statNumber:{fontSize:19,color:'white',fontWeight:'900',marginVertical:3},
  bigNumber:{fontSize:27,color:GREEN,fontWeight:'900',marginVertical:8},
  track:{height:7,backgroundColor:'#343A30',borderRadius:6,overflow:'hidden',marginVertical:12},
  fill:{height:7,backgroundColor:GREEN,borderRadius:6},
  greenButton:{backgroundColor:GREEN,padding:15,borderRadius:11,alignItems:'center',marginTop:14},
  greenButtonText:{fontSize:11,color:'#11150D',fontWeight:'900',letterSpacing:1},
  secondaryButton:{backgroundColor:'#303D25',padding:12,borderRadius:10,alignItems:'center',marginTop:12},
  secondaryButtonText:{fontSize:10,color:GREEN,fontWeight:'900'},
  avatar:{width:43,height:43,borderRadius:22,backgroundColor:CARD,borderWidth:1,borderColor:GREEN,alignItems:'center',justifyContent:'center'},
  avatarText:{fontSize:18,color:GREEN,fontWeight:'900'},
  coachCard:{backgroundColor:CARD,borderRadius:15,padding:16,flexDirection:'row',alignItems:'center',gap:12,marginBottom:15},
  coachIcon:{fontSize:28,color:GREEN,marginBottom:10},
  cardTitle:{fontSize:14,color:'white',fontWeight:'900',marginBottom:5},
  weekRow:{flexDirection:'row',justifyContent:'space-between'},
  weekDay:{alignItems:'center',gap:8},
  dayDot:{width:31,height:31,borderRadius:16,backgroundColor:'#30352C',alignItems:'center',justifyContent:'center'},
  dayDotDone:{backgroundColor:GREEN},
  dayDotText:{fontSize:11,color:'white',fontWeight:'900'},
  exercise:{backgroundColor:CARD,borderRadius:13,padding:14,flexDirection:'row',alignItems:'center',gap:12,marginBottom:9},
  exerciseEmoji:{fontSize:23},
  exerciseCheck:{fontSize:22,color:GREEN},
  input:{backgroundColor:CARD,borderWidth:1,borderColor:'#343A30',borderRadius:11,padding:15,color:'white',fontSize:14,marginTop:9},
  optionCard:{backgroundColor:CARD,borderWidth:1,borderColor:'#30352C',borderRadius:13,padding:17,marginBottom:10,flexDirection:'row',justifyContent:'space-between',alignItems:'center'},
  optionSelected:{borderColor:GREEN,backgroundColor:'#303D25'},
  optionText:{color:'white',fontWeight:'800',fontSize:14},
  progressRow:{flexDirection:'row',gap:5,marginVertical:18},
  stepBar:{flex:1,height:5,borderRadius:5},
  profileRow:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',paddingVertical:12,borderBottomWidth:1,borderBottomColor:'#30352C'},
  profileValue:{fontSize:12,color:GREEN,fontWeight:'900'},
  row:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',gap:10,marginTop:8},
  chip:{backgroundColor:CARD,borderWidth:1,borderColor:'#30352C',borderRadius:20,paddingVertical:9,paddingHorizontal:14,marginRight:8},
  chipActive:{backgroundColor:GREEN,borderColor:GREEN},
  chipText:{fontSize:11,color:MUTED,fontWeight:'800'},
  macroRow:{flexDirection:'row',gap:7},
  macroCard:{flex:1,backgroundColor:CARD,borderRadius:13,padding:11},
  chatBubble:{padding:13,borderRadius:13,marginTop:12,maxWidth:'92%'},
  userBubble:{backgroundColor:'#35442A',alignSelf:'flex-end'},
  coachBubble:{backgroundColor:'#252D20',alignSelf:'flex-start'},
  chatText:{fontSize:13,color:'white',lineHeight:20},
  tabBar:{height:68,backgroundColor:'#171A15',borderTopWidth:1,borderTopColor:'#30352C',flexDirection:'row',justifyContent:'space-around',alignItems:'center',paddingBottom:5},
  tab:{flex:1,alignItems:'center',justifyContent:'center'},
  tabIcon:{fontSize:19,color:MUTED,marginBottom:4},
  tabLabel:{fontSize:9,color:MUTED,fontWeight:'800'},
  achievement:{backgroundColor:CARD,borderRadius:13,padding:14,flexDirection:'row',alignItems:'center',gap:12,marginBottom:9},
  achievementIcon:{fontSize:25,width:35,textAlign:'center'},
  chart:{height:145,flexDirection:'row',justifyContent:'space-around',alignItems:'flex-end',paddingTop:10},
  chartColumn:{flex:1,alignItems:'center',justifyContent:'flex-end',gap:8,height:'100%'},
  chartBar:{width:17,borderRadius:6,minHeight:8},
  danger:{fontSize:10,color:'#E58B7F',fontWeight:'900'}
});